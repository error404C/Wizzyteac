import os
import sqlite3
import subprocess
import time
from functools import wraps
from flask import (
    Flask, render_template, request, redirect,
    url_for, session, jsonify, flash
)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "wtc-wizzy-tech-host-secret-2024")

BOTS_DIR = "hosted_bots"
LOG_DIR  = "logs"
os.makedirs(BOTS_DIR, exist_ok=True)
os.makedirs(LOG_DIR,  exist_ok=True)

# ── Hardcoded admin credentials ───────────────────────────────────────────
ADMIN_EMAIL    = "adminwizzy@gmail.com"
ADMIN_PASSWORD = "admin123@"
ADMIN_USERNAME = "WizzyAdmin"

# ── Running processes ─────────────────────────────────────────────────────
running_processes = {}

# ── Database ──────────────────────────────────────────────────────────────
def get_db():
    conn = sqlite3.connect("wtc.db", check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id       INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email    TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role     TEXT DEFAULT 'user',
            created  TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS bots (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id   INTEGER NOT NULL,
            name      TEXT NOT NULL,
            file_path TEXT,
            status    TEXT DEFAULT 'stopped',
            token     TEXT DEFAULT '',
            created   TEXT DEFAULT (datetime('now')),
            FOREIGN KEY(user_id) REFERENCES users(id)
        );
    """)
    # Ensure admin account always exists with correct credentials
    existing = conn.execute("SELECT id FROM users WHERE email=?", (ADMIN_EMAIL,)).fetchone()
    if not existing:
        conn.execute(
            "INSERT INTO users (username,email,password,role) VALUES (?,?,?,?)",
            (ADMIN_USERNAME, ADMIN_EMAIL, generate_password_hash(ADMIN_PASSWORD), "admin")
        )
        conn.commit()
    else:
        # Always keep admin password in sync with the hardcoded value
        conn.execute(
            "UPDATE users SET password=?, role='admin' WHERE email=?",
            (generate_password_hash(ADMIN_PASSWORD), ADMIN_EMAIL)
        )
        conn.commit()
    conn.close()

init_db()

# ── Helpers ───────────────────────────────────────────────────────────────
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if session.get("role") != "admin":
            flash("Admin access required.", "error")
            return redirect(url_for("dashboard"))
        return f(*args, **kwargs)
    return decorated

def get_current_user():
    if "user_id" not in session:
        return None
    conn = get_db()
    user = conn.execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()
    conn.close()
    return user

def allowed_file(filename):
    return filename.endswith(".py")

# ── Auth ──────────────────────────────────────────────────────────────────
@app.route("/")
def index():
    return redirect(url_for("dashboard") if "user_id" in session else url_for("login"))

@app.route("/login", methods=["GET", "POST"])
def login():
    if "user_id" in session:
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        email    = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        conn = get_db()
        user = conn.execute("SELECT * FROM users WHERE LOWER(email)=?", (email,)).fetchone()
        conn.close()
        if user and check_password_hash(user["password"], password):
            session["user_id"]  = user["id"]
            session["username"] = user["username"]
            session["role"]     = user["role"]
            return redirect(url_for("dashboard"))
        flash("Invalid email or password.", "error")
    return render_template("login.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if "user_id" in session:
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email    = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        confirm  = request.form.get("confirm", "")
        if not username or not email or not password:
            flash("All fields are required.", "error")
        elif password != confirm:
            flash("Passwords do not match.", "error")
        elif len(password) < 6:
            flash("Password must be at least 6 characters.", "error")
        elif email == ADMIN_EMAIL.lower():
            flash("That email is not available.", "error")
        else:
            try:
                conn = get_db()
                conn.execute(
                    "INSERT INTO users (username,email,password) VALUES (?,?,?)",
                    (username, email, generate_password_hash(password))
                )
                conn.commit()
                conn.close()
                flash("Account created! Please sign in.", "success")
                return redirect(url_for("login"))
            except sqlite3.IntegrityError:
                flash("Username or email already taken.", "error")
    return render_template("register.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

# ── Dashboard ─────────────────────────────────────────────────────────────
@app.route("/dashboard")
@login_required
def dashboard():
    user = get_current_user()
    conn = get_db()
    if user["role"] == "admin":
        bots = conn.execute(
            "SELECT b.*, u.username FROM bots b JOIN users u ON b.user_id=u.id ORDER BY b.created DESC"
        ).fetchall()
    else:
        bots = conn.execute(
            "SELECT b.*, u.username FROM bots b JOIN users u ON b.user_id=u.id WHERE b.user_id=? ORDER BY b.created DESC",
            (user["id"],)
        ).fetchall()
    stats = {
        "total":   len(bots),
        "running": sum(1 for b in bots if b["status"] == "running"),
        "stopped": sum(1 for b in bots if b["status"] == "stopped"),
    }
    conn.close()
    return render_template("dashboard.html", bots=bots, stats=stats, user=user)

# ── Upload ────────────────────────────────────────────────────────────────
@app.route("/upload", methods=["GET", "POST"])
@login_required
def upload():
    user = get_current_user()
    if request.method == "POST":
        name  = request.form.get("name", "").strip()
        token = request.form.get("token", "").strip()
        file  = request.files.get("file")
        if not name:
            flash("Bot name is required.", "error")
        elif not file or not allowed_file(file.filename):
            flash("Please upload a valid .py file.", "error")
        else:
            filename  = secure_filename(file.filename)
            save_path = os.path.join(BOTS_DIR, f"u{user['id']}_{filename}")
            file.save(save_path)
            conn = get_db()
            conn.execute(
                "INSERT INTO bots (user_id,name,file_path,token) VALUES (?,?,?,?)",
                (user["id"], name, save_path, token)
            )
            conn.commit()
            conn.close()
            flash(f'"{name}" uploaded successfully!', "success")
            return redirect(url_for("dashboard"))
    return render_template("upload.html", user=user)

# ── Bot Detail ────────────────────────────────────────────────────────────
@app.route("/bot/<int:bot_id>")
@login_required
def bot_detail(bot_id):
    user = get_current_user()
    conn = get_db()
    bot  = conn.execute("SELECT * FROM bots WHERE id=?", (bot_id,)).fetchone()
    conn.close()
    if not bot:
        flash("Bot not found.", "error")
        return redirect(url_for("dashboard"))
    if bot["user_id"] != user["id"] and user["role"] != "admin":
        flash("Access denied.", "error")
        return redirect(url_for("dashboard"))
    log_path = f"{LOG_DIR}/{bot_id}.log"
    log_content = ""
    if os.path.exists(log_path):
        with open(log_path, "r") as f:
            log_content = f.read()[-8000:]
    return render_template("bot_detail.html", bot=bot, log=log_content, user=user)

# ── Bot API ───────────────────────────────────────────────────────────────
def get_bot_or_403(bot_id):
    user = get_current_user()
    conn = get_db()
    bot  = conn.execute("SELECT * FROM bots WHERE id=?", (bot_id,)).fetchone()
    conn.close()
    if not bot or (bot["user_id"] != user["id"] and user["role"] != "admin"):
        return None, None
    return bot, user

@app.route("/api/bot/<int:bot_id>/start", methods=["POST"])
@login_required
def api_start(bot_id):
    bot, user = get_bot_or_403(bot_id)
    if not bot:
        return jsonify({"ok": False, "error": "Access denied"}), 403
    if bot_id in running_processes:
        return jsonify({"ok": False, "error": "Already running"})
    log_path = f"{LOG_DIR}/{bot_id}.log"
    log_file = open(log_path, "a")
    process  = subprocess.Popen(
        ["python3", "-u", bot["file_path"]],
        stdout=log_file, stderr=log_file, env=os.environ.copy()
    )
    running_processes[bot_id] = (process, log_file)
    conn = get_db()
    conn.execute("UPDATE bots SET status='running' WHERE id=?", (bot_id,))
    conn.commit(); conn.close()
    return jsonify({"ok": True, "status": "running"})

@app.route("/api/bot/<int:bot_id>/stop", methods=["POST"])
@login_required
def api_stop(bot_id):
    bot, user = get_bot_or_403(bot_id)
    if not bot:
        return jsonify({"ok": False, "error": "Access denied"}), 403
    proc = running_processes.pop(bot_id, None)
    if proc:
        proc[0].kill(); proc[1].close()
    conn = get_db()
    conn.execute("UPDATE bots SET status='stopped' WHERE id=?", (bot_id,))
    conn.commit(); conn.close()
    return jsonify({"ok": True, "status": "stopped"})

@app.route("/api/bot/<int:bot_id>/restart", methods=["POST"])
@login_required
def api_restart(bot_id):
    api_stop(bot_id)
    time.sleep(1)
    return api_start(bot_id)

@app.route("/api/bot/<int:bot_id>/logs")
@login_required
def api_logs(bot_id):
    bot, user = get_bot_or_403(bot_id)
    if not bot:
        return jsonify({"ok": False}), 403
    log_path = f"{LOG_DIR}/{bot_id}.log"
    content  = open(log_path).read()[-6000:] if os.path.exists(log_path) else "No logs yet."
    return jsonify({"ok": True, "logs": content})

@app.route("/api/bot/<int:bot_id>/clear_logs", methods=["POST"])
@login_required
def api_clear_logs(bot_id):
    bot, user = get_bot_or_403(bot_id)
    if not bot:
        return jsonify({"ok": False}), 403
    open(f"{LOG_DIR}/{bot_id}.log", "w").close()
    return jsonify({"ok": True})

@app.route("/api/bot/<int:bot_id>/token", methods=["POST"])
@login_required
def api_token(bot_id):
    bot, user = get_bot_or_403(bot_id)
    if not bot:
        return jsonify({"ok": False}), 403
    token = request.json.get("token", "")
    conn  = get_db()
    conn.execute("UPDATE bots SET token=? WHERE id=?", (token, bot_id))
    conn.commit(); conn.close()
    return jsonify({"ok": True})

@app.route("/api/bot/<int:bot_id>/delete", methods=["POST"])
@login_required
def api_delete(bot_id):
    bot, user = get_bot_or_403(bot_id)
    if not bot:
        return jsonify({"ok": False}), 403
    proc = running_processes.pop(bot_id, None)
    if proc:
        proc[0].kill(); proc[1].close()
    if bot["file_path"] and os.path.exists(bot["file_path"]):
        os.remove(bot["file_path"])
    log_path = f"{LOG_DIR}/{bot_id}.log"
    if os.path.exists(log_path):
        os.remove(log_path)
    conn = get_db()
    conn.execute("DELETE FROM bots WHERE id=?", (bot_id,))
    conn.commit(); conn.close()
    return jsonify({"ok": True})

# ── Admin Panel ───────────────────────────────────────────────────────────
@app.route("/admin")
@login_required
@admin_required
def admin_panel():
    user  = get_current_user()
    conn  = get_db()
    users = conn.execute("SELECT * FROM users ORDER BY created DESC").fetchall()
    bots  = conn.execute(
        "SELECT b.*, u.username FROM bots b JOIN users u ON b.user_id=u.id ORDER BY b.created DESC"
    ).fetchall()
    conn.close()
    return render_template("admin.html", users=users, bots=bots, user=user)

@app.route("/admin/delete_user/<int:uid>", methods=["POST"])
@login_required
@admin_required
def delete_user(uid):
    conn = get_db()
    u = conn.execute("SELECT email FROM users WHERE id=?", (uid,)).fetchone()
    if u and u["email"] == ADMIN_EMAIL:
        conn.close()
        return jsonify({"ok": False, "error": "Cannot delete admin"})
    conn.execute("DELETE FROM bots WHERE user_id=?", (uid,))
    conn.execute("DELETE FROM users WHERE id=?",     (uid,))
    conn.commit(); conn.close()
    return jsonify({"ok": True})

@app.route("/admin/promote/<int:uid>", methods=["POST"])
@login_required
@admin_required
def promote_user(uid):
    conn = get_db()
    conn.execute("UPDATE users SET role='admin' WHERE id=?", (uid,))
    conn.commit(); conn.close()
    return jsonify({"ok": True})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
