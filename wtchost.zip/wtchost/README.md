# ⬡ Wizzy Tech Host (WTC)

A multi-user web panel to upload and run Telegram bots on a server.

## Admin Login
- **Email:** adminwizzy@gmail.com
- **Password:** admin123@

## Deploy to Render

### 1. Push to GitHub
```bash
git init
git add .
git commit -m "WTC Host"
git remote add origin https://github.com/YOUR_USERNAME/wtchost.git
git push -u origin main
```

### 2. Deploy on Render
1. Go to render.com → sign up with GitHub
2. New → Web Service → select your repo
3. Render reads render.yaml automatically
4. Click Deploy — done in ~2 min

### 3. Open your site
- Visit the Render URL
- Login with admin credentials above
- Regular users can sign up on /register

## File Structure
```
wtchost/
├── app.py
├── requirements.txt
├── render.yaml
├── .gitignore
├── README.md
└── templates/
    ├── base.html
    ├── login.html
    ├── register.html
    ├── dashboard.html
    ├── bot_detail.html
    ├── upload.html
    └── admin.html
```
